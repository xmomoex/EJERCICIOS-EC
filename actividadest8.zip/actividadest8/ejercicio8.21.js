// Error en tiempo de desarrollo:
console.log("variableNoDefinida";
// Error en tiempo de ejecución:
console.log(numero);
