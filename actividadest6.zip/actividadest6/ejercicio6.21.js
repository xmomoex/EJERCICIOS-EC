let dataWith = prompt("Introduce el ancho");
let dataHeigt = prompt("Introduce el alto");
let dataColor = prompt("Introduce el color de borde");

const caja = document.querySelector("div");
caja.dataset.with = dataWith;
caja.dataset.heigt = dataHeigt;
caja.dataset.bordercolor = dataBorderColor;
