//declaro la variable
let parrafo = document.getElementById("parrafo");
//modifico los estilos como quiera
parrafo.style.color = "purple";
parrafo.style.fontSize = "30px";
