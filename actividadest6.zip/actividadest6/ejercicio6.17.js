let lista = document.getElementById("lista");
//guado el primero y el ultimo
let primerNombre = lista.firstElementChild.textContent;
let ultimoNombre = lista.lastElementChild.textContent;
//los devuelvo por consola
console.log("Primer nombre:", primerNombre);
console.log("Último nombre:", ultimoNombre);
